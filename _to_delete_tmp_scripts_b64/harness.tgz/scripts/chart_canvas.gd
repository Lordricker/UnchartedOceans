class_name ChartCanvas
extends Node2D
## The whole world chart drawn out as one picture, for the chart on the cabin table (ship_map.gd puts it on the
## table through a SubViewport). Land and sea come from the chart's own images; on top of them go a km grid with a
## scale bar, every port by its id, the destination, the planned route, and the ship.
##
## The ship is a marker with a ring round it. The ring grows the longer you have been away from the last port you
## were in (a master out of sight of land is never quite sure where he is): ring_base_km plus ring_per_km of the
## distance from that port.

const REGION_COLORS := {
	"A": Color(0.35, 0.62, 1.0),
	"B": Color(1.0, 0.80, 0.25),
	"C": Color(1.0, 0.42, 0.32),
	"D": Color(0.45, 1.0, 0.55),
	"F": Color(0.90, 0.50, 1.0),
}
const INK := Color(0.96, 0.92, 0.80)
const GOLD := Color(1.0, 0.82, 0.25)

var streamer: Node
var size_px := Vector2(2048, 1365)
var grid_km := 50.0
var ring_base_km := 2.0
var ring_per_km := 0.02
var active := true
## The ship's dot is drawn 1/dot_scale of its size: the magnifying glass sets this to its zoom so the dot stays small.
var dot_scale := 1.0

var _chart: WorldChart
var _scale := 1.0                 # canvas pixels per chart pixel
var _font: Font
var _last_port := Vector2.INF     # chart metres

func _ready() -> void:
	_font = _find_font()

func _find_font() -> Font:
	if ResourceLoader.exists("res://assets/fonts/IMFellEnglish-Regular.ttf"):
		var f := load("res://assets/fonts/IMFellEnglish-Regular.ttf") as Font
		if f:
			return f
	return ThemeDB.fallback_font

## Call once the streamer has loaded its chart.
func setup(st: Node, chart: WorldChart) -> void:
	streamer = st
	_chart = chart
	_scale = size_px.x / float(chart.px_w)
	var sprite := Sprite2D.new()
	sprite.centered = false
	sprite.show_behind_parent = true
	sprite.texture = load(WorldChart.HEIGHT_PATH) as Texture2D
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	sprite.scale = Vector2(_scale, _scale)
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/world_chart.gdshader") as Shader
	mat.set_shader_parameter("land_tex", load(WorldChart.LAND_PATH))
	mat.set_shader_parameter("shore_tex", load(WorldChart.SHORE_PATH))
	mat.set_shader_parameter("shelf_px", 12000.0 / chart.mpp)
	sprite.material = mat
	add_child(sprite)
	var home := chart.get_port(String(st.get("home_port_id")))
	if not home.is_empty():
		_last_port = Vector2(float(home["x"]), float(home["z"]))

func _p(x: float, z: float) -> Vector2:
	return Vector2(x, z) / _chart.mpp * _scale

func _process(_delta: float) -> void:
	if _chart == null or streamer == null:
		return
	# remember the last port you were in (inside its spawn ring)
	var cx := float(streamer.call("ship_cx"))
	var cz := float(streamer.call("ship_cz"))
	var np := _chart.nearest_port(cx, cz)
	if not np.is_empty() and float(np["dist_m"]) <= WorldChart.PORT_SPAWN_M:
		_last_port = Vector2(float(np["x"]), float(np["z"]))
	if active:
		queue_redraw()

func _text(pos: Vector2, s: String, size: int, col: Color, center := false) -> void:
	if center:
		pos.x -= _font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x * 0.5
	draw_string_outline(_font, pos, s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 5, Color(0, 0, 0, 0.85))
	draw_string(_font, pos, s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)

func _draw() -> void:
	if _chart == null or streamer == null:
		return
	var w_px := _chart.width_m / _chart.mpp * _scale
	var h_px := _chart.height_m / _chart.mpp * _scale
	# km grid
	var step_m := grid_km * 1000.0
	var gx := step_m
	while gx < _chart.width_m:
		var a := _p(gx, 0.0)
		var major := int(round(gx / step_m)) % 2 == 0
		draw_line(a, a + Vector2(0, h_px), Color(1, 1, 1, 0.20 if major else 0.09), 1.5 if major else 1.0)
		if major:
			_text(a + Vector2(4, 22), "%d" % int(round(gx / 1000.0)), 16, Color(INK, 0.7))
		gx += step_m
	var gz := step_m
	while gz < _chart.height_m:
		var b := _p(0.0, gz)
		var major2 := int(round(gz / step_m)) % 2 == 0
		draw_line(b, b + Vector2(w_px, 0), Color(1, 1, 1, 0.20 if major2 else 0.09), 1.5 if major2 else 1.0)
		if major2:
			_text(b + Vector2(6, -6), "%d" % int(round(gz / 1000.0)), 16, Color(INK, 0.7))
		gz += step_m
	# frame
	draw_rect(Rect2(Vector2.ZERO, Vector2(w_px, h_px)), Color(0.12, 0.07, 0.03), false, 10.0)
	# the planned route
	var cx := float(streamer.call("ship_cx"))
	var cz := float(streamer.call("ship_cz"))
	var route: Array = streamer.get("route")
	var ri := int(streamer.get("route_i"))
	if route.size() > 1:      # a dashed course only for a planned multi-leg route; with none the diamond is the only mark
		var pts := PackedVector2Array([_p(cx, cz)])
		for i in range(mini(ri, route.size() - 1), route.size()):
			var wp: Vector2 = route[i]
			pts.append(_p(wp.x, wp.y))
		for i in range(pts.size() - 1):
			draw_dashed_line(pts[i], pts[i + 1], Color(GOLD, 0.75), 3.0, 14.0)
	# ports
	var dest := String(streamer.get("destination"))
	for p in _chart.ports:
		var pos := _p(float(p["x"]), float(p["z"]))
		var col: Color = REGION_COLORS.get(p["region"], Color.WHITE)
		var big: bool = p["tier"] == "capital"
		var r := 9.0 if big else 6.0
		draw_circle(pos, r, Color(0, 0, 0, 0.7))
		draw_arc(pos, r, 0.0, TAU, 20, col, 3.0)
		if String(p["id"]) == dest:
			# the waypoint: a gold diamond on the final destination, no distance
			var dr := r + 14.0
			var diamond := PackedVector2Array([pos + Vector2(0, -dr), pos + Vector2(dr, 0), pos + Vector2(0, dr), pos + Vector2(-dr, 0)])
			draw_colored_polygon(diamond, Color(GOLD, 0.35))
			draw_polyline(PackedVector2Array([diamond[0], diamond[1], diamond[2], diamond[3], diamond[0]]), GOLD, 4.0)
			_text(pos + Vector2(r + 5.0, 6.0), String(p["name"]), 18 if big else 15, GOLD)
		else:
			_text(pos + Vector2(r + 5.0, 6.0), String(p["name"]), 18 if big else 15, INK)
	# the ship: a ring that grows with the distance from the last port, and the marker
	var sp := _p(cx, cz)
	var from_port := 0.0
	if _last_port != Vector2.INF:
		from_port = WorldChart.distance_m(cx, cz, _last_port.x, _last_port.y)
	var ring_m := ring_base_km * 1000.0 + ring_per_km * from_port
	var ring_px := ring_m / _chart.mpp * _scale
	draw_circle(sp, ring_px, Color(1.0, 0.95, 0.4, 0.12))
	draw_arc(sp, ring_px, 0.0, TAU, 64, Color(1.0, 0.95, 0.4, 0.8), 2.5)
	# just a dot: the way you are pointing is read off the compass, not the chart
	draw_circle(sp, 9.0 / dot_scale, Color(1.0, 0.95, 0.4))
	draw_arc(sp, 9.0 / dot_scale, 0.0, TAU, 24, Color(0, 0, 0, 0.9), 2.5 / dot_scale)
	# scale bar (100 km) and north
	var bar := 100000.0 / _chart.mpp * _scale
	var bp := Vector2(40.0, h_px - 46.0)
	draw_line(bp, bp + Vector2(bar, 0), INK, 5.0)
	draw_line(bp + Vector2(0, -9), bp + Vector2(0, 9), INK, 4.0)
	draw_line(bp + Vector2(bar, -9), bp + Vector2(bar, 9), INK, 4.0)
	_text(bp + Vector2(bar * 0.5, -14), "100 km", 20, INK, true)
	var np2 := Vector2(w_px - 60.0, 70.0)
	draw_line(np2 + Vector2(0, 40), np2 + Vector2(0, -26), INK, 4.0)
	draw_colored_polygon(PackedVector2Array([np2 + Vector2(0, -42), np2 + Vector2(-9, -22), np2 + Vector2(9, -22)]), INK)
	_text(np2 + Vector2(0, -50), "N", 26, INK, true)
